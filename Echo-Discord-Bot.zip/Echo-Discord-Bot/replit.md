# Echo Discord Bot

Echo is a Python Discord bot with server utilities, moderation, games, and an optional Groq-powered chat feature.

## Run & Operate

- `bash scripts/build-echo-bot.sh` — install/sync the Python dependencies
- `bash scripts/run-echo-bot.sh` — start the Discord bot
- Replit Secrets: `DISCORD_TOKEN` is required; `GROQ_API_KEY` enables the AI chat feature
- For continuous hosting, use a Reserved VM deployment with the build and run commands above
- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `Echo-main/` — Discord bot source, cogs, JSON configuration, and SQLite data
- `scripts/run-echo-bot.sh` — bot launcher; keeps the bot's expected working directory
- `scripts/build-echo-bot.sh` — syncs Python dependencies with uv

## Architecture decisions

- Discord and Groq credentials are environment variables; never commit real values.
- `GROQ_API_KEY` is optional so missing AI credentials do not block other bot cogs.

## Product

Echo provides Discord server features through independently loaded bot cogs.

## User preferences

-

## Gotchas

- Enable the privileged Message Content Intent in the Discord Developer Portal.
- Start the bot from `Echo-main/` so relative `cogs/` and `data/` paths resolve correctly.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
